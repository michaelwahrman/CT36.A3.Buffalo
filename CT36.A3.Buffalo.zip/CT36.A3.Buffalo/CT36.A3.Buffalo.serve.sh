#!/bin/sh
# Serve this folder so the page reads the real config JSON and art (not the embedded copy).
# Then open http://localhost:8036/CT36.A3.Buffalo.html
cd "$(dirname "$0")" && python3 -m http.server 8036
