#!/usr/bin/env python3
"""CT36.A3.Buffalo - payout simulator.

Plays N random spins with the rules in CT36.A3.Buffalo.config.json (same
evaluation as the page) and reports the return to player (RTP = average
payout / bet) and how often a spin wins anything.

    python3 CT36.A3.Buffalo.rtp_sim.py            # 200,000 spins
    python3 CT36.A3.Buffalo.rtp_sim.py 1000000

Linux / WSL, Python 3 standard library only.
"""
import json, os, random, sys, bisect
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
cfg = json.load(open(os.path.join(HERE, "CT36.A3.Buffalo.config.json"), encoding="utf-8"))
R = cfg["rules"]
pay = {int(k): v for k, v in R["payTable"].items()}


def build_lines():
    L = []
    if R.get("rows", True):
        L += [[(r, c) for c in range(5)] for r in range(5)]
    if R.get("columns", True):
        L += [[(r, c) for r in range(5)] for c in range(5)]
    d = R.get("diagonals", "main")
    if d == "main":
        L += [[(i, i) for i in range(5)], [(i, 4 - i) for i in range(5)]]
    elif d == "all":
        for k in range(-3, 4):
            L.append([(r, r - k) for r in range(5) if 0 <= r - k < 5])
            L.append([(r, 4 - r + k) for r in range(5) if 0 <= 4 - r + k < 5])
    return L


LINES = build_lines()
weights = [s.get("weight", 1) for s in cfg["symbols"]]
cum = []
acc = 0
for w in weights:
    acc += w
    cum.append(acc)


def pick():
    return bisect.bisect_right(cum, random.random() * acc)


def evaluate(g, bet=1.0):
    unit = bet / len(LINES) if R.get("payBasis") == "linebet" else bet
    total, kinds = 0.0, Counter()
    for ln in LINES:
        v = [g[r][c] for r, c in ln]
        i = 0
        while i < len(v):
            j = i
            while j + 1 < len(v) and v[j + 1] == v[i]:
                j += 1
            k = j - i + 1
            if k >= 2 and k in pay and (not R.get("runsMustStartAtEdge") or i == 0):
                total += unit * pay[k]
                kinds[k] += 1
            if R.get("runsMustStartAtEdge"):
                break
            i = j + 1
    return total, kinds


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
    tot, hits, kinds = 0.0, 0, Counter()
    for _ in range(n):
        g = [[pick() for _ in range(5)] for _ in range(5)]
        w, k = evaluate(g)
        tot += w
        hits += w > 0
        kinds.update(k)
    print("rules: lines=%d diagonals=%s runsMustStartAtEdge=%s payBasis=%s symbols=%d"
          % (len(LINES), R.get("diagonals"), R.get("runsMustStartAtEdge"), R.get("payBasis"), len(weights)))
    print("spins: %d" % n)
    print("RTP (payout per 1 bet): %.3f  -> %.1f%%" % (tot / n, 100 * tot / n))
    print("spins that win anything: %.1f%%" % (100 * hits / n))
    for k in sorted(kinds):
        print("  %d-of-a-kind per spin: %.4f" % (k, kinds[k] / n))


if __name__ == "__main__":
    main()
